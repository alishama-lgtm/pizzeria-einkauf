require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { initDatabase } = require('./db/init');

const app = express();
const PORT = process.env.PORT || 3001;

initDatabase();

app.use(cors({ origin: ['http://localhost:5173', 'null', '*'] }));
app.use(express.json());

// Routes
app.use('/api/auth',          require('./api/auth'));
app.use('/api/inventory',     require('./api/inventory'));
app.use('/api/shopping-list', require('./api/shopping'));
app.use('/api/suppliers',     require('./api/suppliers'));
app.use('/api/dashboard',     require('./api/dashboard'));

// Health
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString(), version: '2.0' });
});

app.listen(PORT, () => {
  console.log(`[Server] http://localhost:${PORT}`);
});
