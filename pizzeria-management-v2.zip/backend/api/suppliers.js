const express = require('express');
const db = require('../db/database');
const { verifyToken, checkRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/suppliers
router.get('/', verifyToken, (req, res) => {
  const suppliers = db.prepare('SELECT * FROM suppliers ORDER BY name').all();
  // Attach product count
  const result = suppliers.map(s => ({
    ...s,
    product_count: db.prepare('SELECT COUNT(*) as c FROM inventory WHERE supplier_id = ?').get(s.id)?.c || 0
  }));
  res.json(result);
});

// POST /api/suppliers
router.post('/', verifyToken, checkRole('admin', 'manager'), (req, res) => {
  const { name, contact_person, phone, email, address, notes } = req.body;
  if (!name) return res.status(400).json({ error: 'Name erforderlich' });

  const r = db.prepare(`
    INSERT INTO suppliers (name, contact_person, phone, email, address, notes)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(name, contact_person || '', phone || '', email || '', address || '', notes || '');

  res.status(201).json(db.prepare('SELECT * FROM suppliers WHERE id = ?').get(r.lastInsertRowid));
});

// DELETE /api/suppliers/:id  (admin only)
router.delete('/:id', verifyToken, checkRole('admin'), (req, res) => {
  const id = parseInt(req.params.id);
  db.prepare('DELETE FROM suppliers WHERE id = ?').run(id);
  res.json({ ok: true });
});

module.exports = router;
