const express = require('express');
const db = require('../db/database');
const { verifyToken, checkRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/inventory
router.get('/', verifyToken, (req, res) => {
  const items = db.prepare(`
    SELECT i.*, s.name as supplier_name,
      CASE WHEN i.current_stock < i.min_stock THEN 1 ELSE 0 END as low_stock
    FROM inventory i
    LEFT JOIN suppliers s ON i.supplier_id = s.id
    ORDER BY i.name
  `).all();
  res.json(items);
});

// PUT /api/inventory/:id/stock  (reduce or refill)
router.put('/:id/stock', verifyToken, checkRole('admin', 'manager', 'employee'), (req, res) => {
  const { amount, reason } = req.body;
  const id = parseInt(req.params.id);

  if (typeof amount !== 'number') {
    return res.status(400).json({ error: 'amount muss eine Zahl sein' });
  }

  const item = db.prepare('SELECT * FROM inventory WHERE id = ?').get(id);
  if (!item) return res.status(404).json({ error: 'Produkt nicht gefunden' });

  const newStock = Math.round((item.current_stock + amount) * 100) / 100;
  if (newStock < 0) return res.status(400).json({ error: 'Bestand kann nicht negativ werden' });

  db.prepare('UPDATE inventory SET current_stock = ? WHERE id = ?').run(newStock, id);
  db.prepare(`
    INSERT INTO stock_history (inventory_id, change_amount, reason, user_id, username)
    VALUES (?, ?, ?, ?, ?)
  `).run(id, amount, reason || '', req.user.id, req.user.username);

  res.json({ ...item, current_stock: newStock, low_stock: newStock < item.min_stock ? 1 : 0 });
});

module.exports = router;
