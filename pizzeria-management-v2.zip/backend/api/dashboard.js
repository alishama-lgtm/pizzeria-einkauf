const express = require('express');
const db = require('../db/database');
const { verifyToken } = require('../middleware/auth');

const router = express.Router();

// GET /api/dashboard/stats
router.get('/stats', verifyToken, (req, res) => {
  const totalValue = db.prepare(
    'SELECT ROUND(SUM(current_stock * price_per_unit), 2) as total FROM inventory'
  ).get();

  const lowStock = db.prepare(
    'SELECT COUNT(*) as count FROM inventory WHERE current_stock < min_stock'
  ).get();

  const shoppingCost = db.prepare(
    'SELECT ROUND(SUM((min_stock - current_stock) * price_per_unit), 2) as total FROM inventory WHERE current_stock < min_stock'
  ).get();

  const supplierCount = db.prepare('SELECT COUNT(*) as count FROM suppliers').get();

  const recentChanges = db.prepare(`
    SELECT sh.change_amount, sh.reason, sh.username, sh.created_at,
           i.name as ingredient_name, i.unit
    FROM stock_history sh
    JOIN inventory i ON sh.inventory_id = i.id
    ORDER BY sh.created_at DESC
    LIMIT 5
  `).all();

  res.json({
    total_stock_value:       totalValue.total || 0,
    low_stock_count:         lowStock.count,
    estimated_shopping_cost: shoppingCost.total || 0,
    supplier_count:          supplierCount.count,
    recent_changes:          recentChanges,
  });
});

module.exports = router;
