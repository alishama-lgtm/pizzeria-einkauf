const express = require('express');
const db = require('../db/database');
const { verifyToken } = require('../middleware/auth');

const router = express.Router();

// GET /api/shopping-list
router.get('/', verifyToken, (req, res) => {
  const items = db.prepare(`
    SELECT
      i.id, i.name, i.unit,
      i.current_stock, i.min_stock,
      i.price_per_unit,
      s.name as supplier_name,
      ROUND(i.min_stock - i.current_stock, 2) as missing_amount,
      ROUND((i.min_stock - i.current_stock) * i.price_per_unit, 2) as estimated_cost
    FROM inventory i
    LEFT JOIN suppliers s ON i.supplier_id = s.id
    WHERE i.current_stock < i.min_stock
    ORDER BY (i.min_stock - i.current_stock) DESC
  `).all();

  const total_cost = Math.round(items.reduce((s, i) => s + (i.estimated_cost || 0), 0) * 100) / 100;
  res.json({ items, total_cost });
});

module.exports = router;
