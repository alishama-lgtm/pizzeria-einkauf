require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('./database');

function initDatabase() {
  // ── Users ─────────────────────────────────────────────────────────
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('admin','manager','employee','kitchen')),
      display_name TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // ── Suppliers ─────────────────────────────────────────────────────
  db.exec(`
    CREATE TABLE IF NOT EXISTS suppliers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      contact_person TEXT DEFAULT '',
      phone TEXT DEFAULT '',
      email TEXT DEFAULT '',
      address TEXT DEFAULT '',
      notes TEXT DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // ── Inventory ─────────────────────────────────────────────────────
  db.exec(`
    CREATE TABLE IF NOT EXISTS inventory (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      unit TEXT NOT NULL,
      current_stock REAL DEFAULT 0,
      min_stock REAL DEFAULT 0,
      price_per_unit REAL DEFAULT 0,
      supplier_id INTEGER REFERENCES suppliers(id),
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // ── Stock History ─────────────────────────────────────────────────
  db.exec(`
    CREATE TABLE IF NOT EXISTS stock_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      inventory_id INTEGER NOT NULL REFERENCES inventory(id),
      change_amount REAL NOT NULL,
      reason TEXT DEFAULT '',
      user_id INTEGER,
      username TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // ── Seed Users ────────────────────────────────────────────────────
  const insertUser = db.prepare(
    'INSERT OR IGNORE INTO users (username, password_hash, role, display_name) VALUES (?, ?, ?, ?)'
  );
  const seedUsers = [
    { u: 'admin',    p: 'admin123',    r: 'admin',    d: 'Administrator' },
    { u: 'manager',  p: 'manager123',  r: 'manager',  d: 'Manager' },
    { u: 'employee', p: 'employee123', r: 'employee', d: 'Mitarbeiter' },
    { u: 'kitchen',  p: 'kitchen123',  r: 'kitchen',  d: 'Küche' },
  ];
  for (const u of seedUsers) {
    insertUser.run(u.u, bcrypt.hashSync(u.p, 10), u.r, u.d);
  }

  // ── Seed Suppliers ────────────────────────────────────────────────
  const insertSupplier = db.prepare(
    'INSERT OR IGNORE INTO suppliers (id, name, contact_person, phone, email) VALUES (?, ?, ?, ?, ?)'
  );
  insertSupplier.run(1, 'Metro',    'Herr Müller',   '+43 1 234 5678', 'metro@lieferant.at');
  insertSupplier.run(2, 'UM Trade', 'Herr Salih',    '+43 664 111 222', 'info@umtrade.at');
  insertSupplier.run(3, 'Etsan',    'Frau Yildiz',   '+43 664 333 444', 'etsan@lieferant.at');

  // ── Seed Inventory ────────────────────────────────────────────────
  const insertItem = db.prepare(
    'INSERT OR IGNORE INTO inventory (id, name, unit, current_stock, min_stock, price_per_unit, supplier_id) VALUES (?, ?, ?, ?, ?, ?, ?)'
  );
  const items = [
    [1,  'Mehl',          'kg',    8,  10, 0.80, 1],
    [2,  'Käse',          'kg',    12, 8,  6.50, 2],
    [3,  'Tomatensoße',   'l',     3,  5,  2.20, 2],
    [4,  'Salami',        'kg',    5,  4,  8.90, 2],
    [5,  'Schinken',      'kg',    2,  4,  9.50, 2],
    [6,  'Champignons',   'kg',    7,  3,  3.20, 1],
    [7,  'Zwiebeln',      'kg',    10, 5,  0.90, 1],
    [8,  'Olivenöl',      'l',     4,  3,  5.80, 3],
    [9,  'Eier',          'Stück', 24, 30, 0.30, 1],
    [10, 'Sahne',         'l',     6,  4,  1.90, 1],
    [11, 'Hackfleisch',   'kg',    1,  5,  7.20, 2],
    [12, 'Hähnchenbrust', 'kg',    3,  4,  8.50, 2],
    [13, 'Pommes',        'kg',    8,  6,  2.10, 1],
    [14, 'Mozzarella',    'kg',    4,  5,  7.80, 3],
    [15, 'Thunfisch',     'kg',    2,  3,  11.50, 3],
  ];
  for (const item of items) insertItem.run(...item);

  console.log('[DB] Initialized — Phase 2');
}

module.exports = { initDatabase };

if (require.main === module) {
  initDatabase();
  process.exit(0);
}
