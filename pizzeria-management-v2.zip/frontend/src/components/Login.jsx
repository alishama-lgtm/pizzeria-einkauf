import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';

const QUICK_LOGINS = [
  { username: 'admin',    password: 'admin123',    label: 'Admin',      color: 'bg-red-600 hover:bg-red-700' },
  { username: 'manager',  password: 'manager123',  label: 'Manager',    color: 'bg-orange-500 hover:bg-orange-600' },
  { username: 'employee', password: 'employee123', label: 'Mitarbeiter',color: 'bg-blue-600 hover:bg-blue-700' },
  { username: 'kitchen',  password: 'kitchen123',  label: 'Küche',      color: 'bg-green-600 hover:bg-green-700' },
];

export default function Login() {
  const { login } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const doLogin = async (u, p) => {
    setError('');
    setLoading(true);
    try {
      await login(u, p);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">🍕</div>
          <h1 className="text-3xl font-bold text-white">Pizzeria San Carino</h1>
          <p className="text-gray-400 mt-1 text-sm">Internes Management-System</p>
        </div>

        <div className="bg-white rounded-2xl shadow-2xl p-8">
          <h2 className="text-xl font-bold text-gray-800 mb-6">Anmelden</h2>

          <form onSubmit={e => { e.preventDefault(); doLogin(username, password); }} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Benutzername</label>
              <input
                type="text"
                value={username}
                onChange={e => setUsername(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none transition"
                placeholder="Benutzername"
                autoComplete="username"
                disabled={loading}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Passwort</label>
              <div className="relative">
                <input
                  type={showPw ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none pr-12 transition"
                  placeholder="Passwort"
                  autoComplete="current-password"
                  disabled={loading}
                />
                <button
                  type="button"
                  onClick={() => setShowPw(!showPw)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-700 text-lg"
                  tabIndex={-1}
                >
                  {showPw ? '🙈' : '👁️'}
                </button>
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
                ⚠️ {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading || !username || !password}
              className="w-full bg-red-700 hover:bg-red-800 disabled:bg-gray-200 disabled:text-gray-400 text-white font-bold py-3 rounded-lg transition-colors"
            >
              {loading ? 'Anmelden...' : 'Anmelden'}
            </button>
          </form>

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-200"></div>
            </div>
            <div className="relative flex justify-center text-xs">
              <span className="px-3 bg-white text-gray-400 font-medium uppercase tracking-wider">Schnell-Login</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {QUICK_LOGINS.map(q => (
              <button
                key={q.username}
                onClick={() => doLogin(q.username, q.password)}
                disabled={loading}
                className={`${q.color} text-white font-semibold py-2.5 px-4 rounded-lg text-sm transition-colors disabled:opacity-50`}
              >
                {q.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
