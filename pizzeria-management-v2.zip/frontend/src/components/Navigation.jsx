import React from 'react';
import { useAuth } from '../contexts/AuthContext';

const ALL_TABS = [
  { id: 'dashboard',       label: 'Dashboard',      icon: '📊' },
  { id: 'inventory',       label: 'Inventar',        icon: '📦' },
  { id: 'shopping-list',   label: 'Einkaufsliste',   icon: '🛒' },
  { id: 'suppliers',       label: 'Lieferanten',     icon: '🏭' },
  { id: 'reports',         label: 'Berichte',        icon: '📈' },
  { id: 'analytics',       label: 'Analytics',       icon: '📉' },
  { id: 'user-management', label: 'Benutzer',        icon: '👥' },
  { id: 'settings',        label: 'Einstellungen',   icon: '⚙️' },
];

export default function Navigation({ activeTab, onTabChange }) {
  const { canAccess } = useAuth();
  const visible = ALL_TABS.filter(t => canAccess(t.id));

  return (
    <nav className="bg-white border-b border-gray-200 px-4 overflow-x-auto">
      <div className="flex min-w-max">
        {visible.map(tab => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
              activeTab === tab.id
                ? 'border-red-700 text-red-700 bg-red-50'
                : 'border-transparent text-gray-500 hover:text-gray-800 hover:border-gray-300'
            }`}
          >
            <span className="text-base">{tab.icon}</span>
            {tab.label}
          </button>
        ))}
      </div>
    </nav>
  );
}
