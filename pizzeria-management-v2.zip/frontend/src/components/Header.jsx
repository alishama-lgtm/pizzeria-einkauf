import React from 'react';
import { useAuth } from '../contexts/AuthContext';

const ROLE_BADGE = {
  admin:    { label: 'ADMIN',      cls: 'bg-red-100 text-red-800 border-red-300' },
  manager:  { label: 'MANAGER',    cls: 'bg-orange-100 text-orange-800 border-orange-300' },
  employee: { label: 'MITARBEITER',cls: 'bg-blue-100 text-blue-800 border-blue-300' },
  kitchen:  { label: 'KÜCHE',      cls: 'bg-green-100 text-green-800 border-green-300' },
};

export default function Header() {
  const { user, logout } = useAuth();
  const badge = ROLE_BADGE[user?.role] || ROLE_BADGE.employee;

  return (
    <header className="bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <span className="text-2xl">🍕</span>
        <div>
          <div className="font-bold text-gray-800 leading-tight">Pizzeria San Carino</div>
          <div className="text-xs text-gray-400">Management System</div>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <span className={`px-3 py-1 rounded-full text-xs font-bold border ${badge.cls}`}>
          {badge.label}
        </span>
        <span className="text-sm font-medium text-gray-700 hidden sm:block">
          {user?.display_name || user?.username}
        </span>
        <button
          onClick={logout}
          className="bg-gray-100 hover:bg-gray-200 text-gray-600 text-sm font-medium px-4 py-2 rounded-lg transition-colors"
        >
          Abmelden
        </button>
      </div>
    </header>
  );
}
