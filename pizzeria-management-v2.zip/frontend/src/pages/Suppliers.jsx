import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';

export default function Suppliers() {
  const { getToken, user } = useAuth();
  const [suppliers, setSuppliers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({ name: '', contact_person: '', phone: '', email: '', address: '', notes: '' });

  const load = () => {
    fetch('/api/suppliers', { headers: { Authorization: `Bearer ${getToken()}` } })
      .then(r => r.json()).then(setSuppliers).finally(() => setLoading(false));
  };

  useEffect(load, []);

  const save = async () => {
    await fetch('/api/suppliers', {
      method: 'POST',
      headers: { Authorization: `Bearer ${getToken()}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    });
    setAdding(false);
    setForm({ name: '', contact_person: '', phone: '', email: '', address: '', notes: '' });
    load();
  };

  if (loading) return <div className="text-center py-20 text-gray-400">Laden...</div>;
  const canEdit = ['admin', 'manager'].includes(user?.role);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-800">Lieferanten</h1>
        {canEdit && (
          <button onClick={() => setAdding(true)}
            className="bg-red-700 hover:bg-red-800 text-white text-sm font-semibold px-4 py-2 rounded-lg">
            + Lieferant hinzufügen
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {suppliers.map(s => (
          <div key={s.id} className="bg-white border border-gray-200 rounded-xl p-5 space-y-2">
            <div className="flex items-start justify-between">
              <div>
                <div className="font-bold text-gray-800 text-lg">{s.name}</div>
                {s.contact_person && <div className="text-sm text-gray-500">👤 {s.contact_person}</div>}
              </div>
              <span className="bg-blue-50 text-blue-700 text-xs font-bold px-2 py-0.5 rounded-full border border-blue-100">
                {s.product_count} Produkte
              </span>
            </div>
            {s.phone && <div className="text-sm text-gray-600">📞 {s.phone}</div>}
            {s.email && <div className="text-sm text-gray-600">✉️ {s.email}</div>}
            {s.address && <div className="text-sm text-gray-500">📍 {s.address}</div>}
            {s.notes && <div className="text-xs text-gray-400 bg-gray-50 rounded p-2 mt-2">{s.notes}</div>}
          </div>
        ))}
      </div>

      {/* Add Modal */}
      {adding && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50" onClick={() => setAdding(false)}>
          <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl" onClick={e => e.stopPropagation()}>
            <h3 className="font-bold text-gray-800 text-lg mb-4">Neuer Lieferant</h3>
            <div className="space-y-3">
              {[['name','Name *'],['contact_person','Ansprechpartner'],['phone','Telefon'],['email','E-Mail'],['address','Adresse'],['notes','Notizen']].map(([k, l]) => (
                <div key={k}>
                  <label className="block text-xs font-medium text-gray-600 mb-1">{l}</label>
                  <input value={form[k]} onChange={e => setForm(p => ({ ...p, [k]: e.target.value }))}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-red-500 outline-none" />
                </div>
              ))}
            </div>
            <div className="flex gap-3 mt-5">
              <button onClick={save} disabled={!form.name}
                className="flex-1 bg-red-700 hover:bg-red-800 disabled:bg-gray-200 text-white font-bold py-2 rounded-lg">
                Speichern
              </button>
              <button onClick={() => setAdding(false)}
                className="flex-1 bg-gray-100 text-gray-700 font-medium py-2 rounded-lg hover:bg-gray-200">
                Abbrechen
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
