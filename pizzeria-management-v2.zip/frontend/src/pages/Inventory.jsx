import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';

export default function Inventory() {
  const { getToken, isReadOnly } = useAuth();
  const readonly = isReadOnly('inventory');
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null); // { id, amount, reason }

  const load = () => {
    fetch('/api/inventory', { headers: { Authorization: `Bearer ${getToken()}` } })
      .then(r => r.json()).then(setItems).finally(() => setLoading(false));
  };

  useEffect(load, []);

  const saveStock = async () => {
    await fetch(`/api/inventory/${editing.id}/stock`, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${getToken()}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount: parseFloat(editing.amount), reason: editing.reason }),
    });
    setEditing(null);
    load();
  };

  if (loading) return <div className="text-center py-20 text-gray-400">Laden...</div>;

  const low = items.filter(i => i.low_stock).length;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-800">Inventar</h1>
        {readonly && <span className="bg-green-100 text-green-700 text-xs font-bold px-3 py-1 rounded-full border border-green-200">NUR LESEN</span>}
        {low > 0 && <span className="bg-red-100 text-red-700 text-sm font-semibold px-3 py-1 rounded-full">{low} unter Mindestbestand</span>}
      </div>

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="text-left px-4 py-3 font-semibold text-gray-600">Produkt</th>
              <th className="text-right px-4 py-3 font-semibold text-gray-600">Bestand</th>
              <th className="text-right px-4 py-3 font-semibold text-gray-600">Minimum</th>
              <th className="text-right px-4 py-3 font-semibold text-gray-600">Preis/Einheit</th>
              <th className="text-left px-4 py-3 font-semibold text-gray-600">Lieferant</th>
              <th className="text-left px-4 py-3 font-semibold text-gray-600">Status</th>
              {!readonly && <th className="px-4 py-3"></th>}
            </tr>
          </thead>
          <tbody>
            {items.map(item => (
              <tr key={item.id} className={`border-b border-gray-50 hover:bg-gray-50 ${item.low_stock ? 'bg-red-50' : ''}`}>
                <td className="px-4 py-3 font-medium text-gray-800">{item.name}</td>
                <td className="px-4 py-3 text-right font-bold">{item.current_stock} {item.unit}</td>
                <td className="px-4 py-3 text-right text-gray-500">{item.min_stock} {item.unit}</td>
                <td className="px-4 py-3 text-right text-gray-500">€ {item.price_per_unit?.toFixed(2)}</td>
                <td className="px-4 py-3 text-gray-500">{item.supplier_name || '—'}</td>
                <td className="px-4 py-3">
                  {item.low_stock
                    ? <span className="bg-red-100 text-red-700 text-xs font-bold px-2 py-0.5 rounded-full">⚠️ Nachbestellen</span>
                    : <span className="bg-green-100 text-green-700 text-xs font-bold px-2 py-0.5 rounded-full">✓ OK</span>
                  }
                </td>
                {!readonly && (
                  <td className="px-4 py-3">
                    <button onClick={() => setEditing({ id: item.id, name: item.name, unit: item.unit, amount: '', reason: '' })}
                      className="text-xs bg-gray-100 hover:bg-gray-200 px-3 py-1 rounded-lg font-medium">
                      Bearbeiten
                    </button>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Edit Modal */}
      {editing && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50" onClick={() => setEditing(null)}>
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-2xl" onClick={e => e.stopPropagation()}>
            <h3 className="font-bold text-gray-800 mb-4">Bestand: {editing.name}</h3>
            <label className="block text-sm font-medium text-gray-600 mb-1">Menge (+ hinzufügen / - entnehmen)</label>
            <input type="number" step="0.1" value={editing.amount}
              onChange={e => setEditing(p => ({ ...p, amount: e.target.value }))}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 mb-3 focus:ring-2 focus:ring-red-500 outline-none"
              placeholder="z.B. -2.5 oder +10" />
            <label className="block text-sm font-medium text-gray-600 mb-1">Grund (optional)</label>
            <input type="text" value={editing.reason}
              onChange={e => setEditing(p => ({ ...p, reason: e.target.value }))}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 mb-4 focus:ring-2 focus:ring-red-500 outline-none"
              placeholder="z.B. Lieferung Metro" />
            <div className="flex gap-3">
              <button onClick={saveStock} disabled={!editing.amount}
                className="flex-1 bg-red-700 hover:bg-red-800 disabled:bg-gray-200 text-white font-bold py-2 rounded-lg transition-colors">
                Speichern
              </button>
              <button onClick={() => setEditing(null)}
                className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium py-2 rounded-lg">
                Abbrechen
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
