import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';

export default function ShoppingList() {
  const { getToken } = useAuth();
  const [data, setData] = useState({ items: [], total_cost: 0 });
  const [loading, setLoading] = useState(true);
  const [ordered, setOrdered] = useState({});

  useEffect(() => {
    fetch('/api/shopping-list', { headers: { Authorization: `Bearer ${getToken()}` } })
      .then(r => r.json()).then(setData).finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="text-center py-20 text-gray-400">Laden...</div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-800">Einkaufsliste</h1>
        <span className="text-sm text-gray-500">{data.items.length} Produkte zum Bestellen</span>
      </div>

      {data.items.length === 0 ? (
        <div className="bg-green-50 border border-green-200 rounded-xl p-8 text-center">
          <div className="text-4xl mb-3">✅</div>
          <p className="font-semibold text-green-700">Alles auf Lager!</p>
          <p className="text-sm text-green-600 mt-1">Kein Produkt unter Mindestbestand.</p>
        </div>
      ) : (
        <>
          <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="text-left px-4 py-3 font-semibold text-gray-600">Produkt</th>
                  <th className="text-right px-4 py-3 font-semibold text-gray-600">Fehlend</th>
                  <th className="text-left px-4 py-3 font-semibold text-gray-600">Lieferant</th>
                  <th className="text-right px-4 py-3 font-semibold text-gray-600">Est. Kosten</th>
                  <th className="px-4 py-3 font-semibold text-gray-600">Status</th>
                </tr>
              </thead>
              <tbody>
                {data.items.map(item => (
                  <tr key={item.id} className="border-b border-gray-50 hover:bg-gray-50">
                    <td className="px-4 py-3 font-medium text-gray-800">{item.name}</td>
                    <td className="px-4 py-3 text-right font-bold text-red-600">{item.missing_amount} {item.unit}</td>
                    <td className="px-4 py-3 text-gray-500">{item.supplier_name || '—'}</td>
                    <td className="px-4 py-3 text-right text-gray-700">€ {item.estimated_cost?.toFixed(2)}</td>
                    <td className="px-4 py-3">
                      <button onClick={() => setOrdered(p => ({ ...p, [item.id]: !p[item.id] }))}
                        className={`text-xs font-bold px-3 py-1 rounded-full border transition-colors ${
                          ordered[item.id]
                            ? 'bg-green-100 text-green-700 border-green-200'
                            : 'bg-yellow-50 text-yellow-700 border-yellow-200 hover:bg-yellow-100'
                        }`}>
                        {ordered[item.id] ? '✓ Bestellt' : 'Ausstehend'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="bg-orange-50 border border-orange-200 rounded-xl px-5 py-4 flex items-center justify-between">
            <span className="font-semibold text-orange-800">Gesamtkosten (geschätzt)</span>
            <span className="text-2xl font-bold text-orange-700">€ {data.total_cost?.toFixed(2)}</span>
          </div>
        </>
      )}
    </div>
  );
}
