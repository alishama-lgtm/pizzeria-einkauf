import React from 'react';
export default function UserManagement() {
  return (
    <div className="text-center py-24">
      <div className="text-5xl mb-4">👥</div>
      <h1 className="text-2xl font-bold text-gray-700">Benutzerverwaltung</h1>
      <p className="text-gray-400 mt-2">Benutzerverwaltung — wird in Phase 4 gebaut</p>
    </div>
  );
}
