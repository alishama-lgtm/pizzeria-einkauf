import React from 'react';
export default function Analytics() {
  return (
    <div className="text-center py-24">
      <div className="text-5xl mb-4">📉</div>
      <h1 className="text-2xl font-bold text-gray-700">Analytics</h1>
      <p className="text-gray-400 mt-2">Analytics — wird in Phase 3 gebaut</p>
    </div>
  );
}
