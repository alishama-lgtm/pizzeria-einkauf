import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';

export default function Dashboard() {
  const { getToken } = useAuth();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/dashboard/stats', { headers: { Authorization: `Bearer ${getToken()}` } })
      .then(r => r.json())
      .then(setStats)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="text-center py-20 text-gray-400">Laden...</div>;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-800">Dashboard</h1>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon="💰" label="Lagerwert gesamt" value={`€ ${stats?.total_stock_value?.toFixed(2)}`} color="bg-blue-50 border-blue-200 text-blue-700" />
        <StatCard icon="⚠️" label="Unter Mindestbestand" value={stats?.low_stock_count} color="bg-red-50 border-red-200 text-red-700" />
        <StatCard icon="🛒" label="Einkaufskosten (est.)" value={`€ ${stats?.estimated_shopping_cost?.toFixed(2)}`} color="bg-orange-50 border-orange-200 text-orange-700" />
        <StatCard icon="🏭" label="Lieferanten" value={stats?.supplier_count} color="bg-green-50 border-green-200 text-green-700" />
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <h2 className="font-bold text-gray-700 mb-3">Letzte Bestandsänderungen</h2>
        {stats?.recent_changes?.length === 0 ? (
          <p className="text-gray-400 text-sm">Noch keine Änderungen.</p>
        ) : (
          <div className="space-y-2">
            {stats?.recent_changes?.map((c, i) => (
              <div key={i} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                <div className="flex items-center gap-3">
                  <span className={`text-sm font-bold ${c.change_amount > 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {c.change_amount > 0 ? '+' : ''}{c.change_amount} {c.unit}
                  </span>
                  <span className="text-sm text-gray-700">{c.ingredient_name}</span>
                  {c.reason && <span className="text-xs text-gray-400">— {c.reason}</span>}
                </div>
                <span className="text-xs text-gray-400">{c.username} · {new Date(c.created_at).toLocaleString('de-AT')}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="flex gap-3">
        <a href="#" onClick={() => {}} className="bg-red-700 hover:bg-red-800 text-white text-sm font-semibold px-5 py-2.5 rounded-lg transition-colors">
          + Bestand hinzufügen
        </a>
        <a href="#" className="bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm font-semibold px-5 py-2.5 rounded-lg transition-colors">
          Einkaufsliste anzeigen →
        </a>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, color }) {
  return (
    <div className={`rounded-xl border p-5 ${color}`}>
      <div className="text-2xl mb-2">{icon}</div>
      <div className="text-2xl font-bold">{value ?? '—'}</div>
      <div className="text-sm font-medium mt-1 opacity-80">{label}</div>
    </div>
  );
}
