import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Login from './components/Login';
import Header from './components/Header';
import Navigation from './components/Navigation';
import Dashboard from './pages/Dashboard';
import Inventory from './pages/Inventory';
import ShoppingList from './pages/ShoppingList';
import Suppliers from './pages/Suppliers';
import Reports from './pages/Reports';
import Analytics from './pages/Analytics';
import UserManagement from './pages/UserManagement';
import Settings from './pages/Settings';

const PAGE_MAP = {
  'dashboard':       Dashboard,
  'inventory':       Inventory,
  'shopping-list':   ShoppingList,
  'suppliers':       Suppliers,
  'reports':         Reports,
  'analytics':       Analytics,
  'user-management': UserManagement,
  'settings':        Settings,
};

function AppContent() {
  const { user, loading, canAccess } = useAuth();
  const [activeTab, setActiveTab] = useState('dashboard');

  useEffect(() => {
    if (user && !canAccess(activeTab)) {
      setActiveTab('dashboard');
    }
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-gray-400 text-sm">Laden...</div>
      </div>
    );
  }

  if (!user) return <Login />;

  const Page = PAGE_MAP[activeTab] || Dashboard;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
      <main className="flex-1 p-6 max-w-7xl mx-auto w-full">
        <Page />
      </main>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
