import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

const AuthContext = createContext(null);

const ROLE_ACCESS = {
  admin:    ['dashboard','inventory','shopping-list','suppliers','reports','analytics','user-management','settings'],
  manager:  ['dashboard','inventory','shopping-list','suppliers','reports'],
  employee: ['dashboard','inventory','shopping-list'],
  kitchen:  ['dashboard','inventory'],
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const logout = useCallback(() => {
    localStorage.removeItem('pm_token');
    localStorage.removeItem('pm_user');
    setUser(null);
  }, []);

  useEffect(() => {
    const token = localStorage.getItem('pm_token');
    const stored = localStorage.getItem('pm_user');
    if (token && stored) {
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        if (payload.exp * 1000 > Date.now()) {
          setUser(JSON.parse(stored));
          const ms = payload.exp * 1000 - Date.now();
          setTimeout(logout, ms);
        } else {
          logout();
        }
      } catch {
        logout();
      }
    }
    setLoading(false);
  }, [logout]);

  const login = async (username, password) => {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Login fehlgeschlagen');
    localStorage.setItem('pm_token', data.token);
    localStorage.setItem('pm_user', JSON.stringify(data.user));
    setUser(data.user);
    const payload = JSON.parse(atob(data.token.split('.')[1]));
    setTimeout(logout, payload.exp * 1000 - Date.now());
    return data.user;
  };

  const canAccess = (tab) => ROLE_ACCESS[user?.role]?.includes(tab) ?? false;
  const isReadOnly = (tab) => user?.role === 'kitchen' && tab === 'inventory';
  const getToken = () => localStorage.getItem('pm_token');

  return (
    <AuthContext.Provider value={{ user, login, logout, canAccess, isReadOnly, getToken, loading }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
export { ROLE_ACCESS };
